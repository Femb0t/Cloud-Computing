#!/usr/bin/env python3

from csv import reader
from pyspark.mllib.clustering import KMeans
from pyspark import SparkContext
import sys
import numpy as np


if __name__ == "__main__":
    sc = SparkContext(appName="extraCredit.py")
    sc.setLogLevel("ERROR")


    data = sc.textFile("hdfs://10.230.119.206:54310/user/cc/crimeData/")

    splitdata = data.mapPartitions(lambda x: reader(x))

    #map function to extract the (location, crime type)
    #and assign a value of 1 if dangerous drugs/weapons, 0 otherwise
    def f(x):
        location = x[16]                #get the location
        crime = x[7]                    #get the crime type
        #return a key value pair where the location and crime is the key and 1 is the value
        if location == "DANGEROUS WEAPONS":
            return ((location, crime), 1)
        if location == "DANGEROUS DRUGS":
            return ((location, crime), 1)
        #this key is not dangerous drugs/weapons so ignore (0)
        return ((location, crime), 0)
    #pairs has the location and the offense description
    parsedData = splitdata.map(f)               #run the map function

    #build the model
    model = KMeans.train(parsedData, 4, maxIterations=10, initializationMode="random")


    #print the results
	#print("Cluster Centers: ", model.clusterCenters)
	#print("Number of Clusters= ", model.k)


    #sc.stop()                              #Not sure if this is needed, saw it in the pi.py example

